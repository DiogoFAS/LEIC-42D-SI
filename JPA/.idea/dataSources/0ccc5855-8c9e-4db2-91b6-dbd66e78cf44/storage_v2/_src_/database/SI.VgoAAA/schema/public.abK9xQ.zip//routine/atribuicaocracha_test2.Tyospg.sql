create procedure atribuicaocracha_test2()
    language plpgsql
as
$$
declare 
    jogadorId int;
	partidaId int default 0;
begin 

    call criarJogador('test', 'test@gmail.com', 'regiaoTest');
	
	select id from Jogador where userName = 'test' into jogadorId;

    insert into Partida(id, nomeJogo, dataFim)
    values (partidaId, 'Tetris', '2023-10-8 14:30');
	
    insert into MultiJogador(idPartida, nomeJogo, estado, nomeRegiao)
    values (partidaId, 'Tetris', 'Por Iniciar', 'regiaoTest');

    insert into Jogar(idPartida, nomeJogo, idJogador, pontuacao)
    values (partidaId, 'Tetris', jogadorId, 150);
	
	update MultiJogador set estado = 'Terminada' where idPartida = partidaId;
	
    if not exists (select * from Tem where idJogador = jogadorId) then
        raise notice 'Test2: Atribuição do cracha com menor pontos requeridos com uma partida MultiJogador: Resultado FAIL';
    else
        raise notice 'Test2: Atribuição do cracha com menor pontos requeridos com uma partida MultiJogador: Resultado OK';
    end if;
    rollback;
end;
$$;

alter procedure atribuicaocracha_test2() owner to postgres;

