create procedure iniciarconversa_test1()
    language plpgsql
as
$$
declare
	JogadorId int;
	idConversa int;
begin
	call criarJogador('Test', 'Test123@gmail.com', 'regiaoTest');
	
	select id into JogadorId from Jogador where email = 'Test123@gmail.com';
	
	call iniciarConversa(JogadorId, 'nomeDaConversa', idConversa);
	
	if not exists (select * from Conversa where id = idConversa) then
		raise notice 'Teste1: iniciar conversa com um jogador existente: Resultado FAIL';
	else
		raise notice 'Teste1: iniciar conversa com um jogador existente: Resultado OK';
	end if;
end;
$$;

alter procedure iniciarconversa_test1() owner to postgres;

