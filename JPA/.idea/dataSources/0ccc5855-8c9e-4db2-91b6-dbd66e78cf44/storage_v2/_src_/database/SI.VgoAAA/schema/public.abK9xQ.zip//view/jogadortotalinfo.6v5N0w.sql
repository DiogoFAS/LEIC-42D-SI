create view jogadortotalinfo
            (id, estado, username, email, totaljogosjogador, totalpontosjogador, totalpartidasjogador) as
SELECT jogador.id,
       jogador.estado,
       jogador.username,
       jogador.email,
       totaljogosjogador(jogador.id)    AS totaljogosjogador,
       totalpontosjogador(jogador.id)   AS totalpontosjogador,
       totalpartidasjogador(jogador.id) AS totalpartidasjogador
FROM jogador
WHERE jogador.estado::text <> 'Banido'::text;

alter table jogadortotalinfo
    owner to postgres;

