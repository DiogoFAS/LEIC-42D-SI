create procedure totalpontosjogador_test4()
    language plpgsql
as
$$
declare 
	totalFunc int;
	invalidIdJogador int default 0;
	msg text;
	correctMsg text;
begin	
	begin 
		select totalPontosJogador(invalidIdJogador)
		into totalFunc;
		exception 
			when others then
				get stacked diagnostics msg = MESSAGE_TEXT;
				
		--correctMsg = 'Jogador com o id % não existe.',invalidIdJogador;
				
		if msg = 'Jogador com o id 0 não existe.' then
			raise notice 'Teste4: Obter total de pontos de jogador inexistente: Resultado OK';
		else
			raise notice 'Teste4: Obter total de pontos de jogador inexistente: Resultado FAIL';
		end if;
	end;
	rollback;
end;
$$;

alter procedure totalpontosjogador_test4() owner to postgres;

