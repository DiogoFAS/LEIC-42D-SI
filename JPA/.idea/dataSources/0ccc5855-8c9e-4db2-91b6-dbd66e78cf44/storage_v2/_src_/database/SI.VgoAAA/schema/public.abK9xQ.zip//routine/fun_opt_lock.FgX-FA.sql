create function fun_opt_lock() returns trigger
    language plpgsql
as
$$
begin
    if TG_OP = 'INSERT' and new.vers is null then
        new.vers = 1;
    elseif TG_OP = 'UPDATE' then
        new.vers = old.vers + 1;
    end if;
    return new;
end;$$;

alter function fun_opt_lock() owner to postgres;

