create procedure iniciarconversalogic(IN idjogador integer, IN nomeconversa character varying, OUT res integer)
    language plpgsql
as
$$
begin
	if not exists(select * from Jogador where id = idJogador) then
		raise exception 'Jogador com o id % não existe.',idJogador;
	end if;

	insert into conversa (idJogador, nome)
	values (idJogador, nomeConversa) returning id into res;
end;
$$;

alter procedure iniciarconversalogic(integer, varchar, out integer) owner to postgres;

