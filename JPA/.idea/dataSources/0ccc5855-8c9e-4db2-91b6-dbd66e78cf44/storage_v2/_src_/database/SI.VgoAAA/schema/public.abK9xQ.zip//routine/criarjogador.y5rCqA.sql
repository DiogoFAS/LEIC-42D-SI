create procedure criarjogador(IN nomejogador character varying, IN emailjogador character varying, IN regiaojogador character varying)
    language plpgsql
as
$$
begin
	if exists (select * from Jogador where userName = nomeJogador) then
		raise exception 'Já existe um jogador com o nome %.', nomeJogador;
	end if;
	
	if exists (select * from Jogador where email = emailJogador) then
		raise exception 'Já existe um jogador com o email %.',emailJogador;
	end if;
	
	if not exists (select * from Regiao where nome = regiaoJogador) then
		insert into Regiao (nome) values (regiaoJogador);
	end if;
	
	insert into Jogador (username, email, nomeRegiao) 
	values (nomeJogador, emailJogador, regiaoJogador);
end;
$$;

alter procedure criarjogador(varchar, varchar, varchar) owner to postgres;

