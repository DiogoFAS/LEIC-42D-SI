create procedure iniciarconversatrans(IN idjogador integer, IN nomeconversa character varying, OUT res integer)
    language plpgsql
as
$$
declare 
	msg text;
begin 
	call iniciarConversaLogic(idJogador, nomeConversa, res);
	exception
		when others then
			get stacked diagnostics msg = MESSAGE_TEXT;
			raise exception '%',msg;
			rollback;
end;
$$;

alter procedure iniciarconversatrans(integer, varchar, out integer) owner to postgres;

