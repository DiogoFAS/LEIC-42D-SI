create procedure juntarconversa_test2()
    language plpgsql
as
$$
declare 
	jogadorId1 int;
	jogadorId2 int;
	conversaId int;
begin
	set transaction isolation level repeatable read;
	call criarJogador('Test1', 'Test1@gmail.com', 'regiaoTest');
	
	call criarJogador('Test2', 'Test2@gmail.com', 'regiaoTest');
	
	select id into jogadorId1 from Jogador where email = 'Test1@gmail.com';
	select id into jogadorId2 from Jogador where email = 'Test2@gmail.com';
	
	call iniciarConversa(jogadorId1, 'ConversaTest', conversaId);

	call juntarConversa(jogadorId2, conversaId);
	
	if not exists (select * from Conversa where idJogador = jogadorId2) then
		raise notice 'Teste2: Jogador existente junta-se a uma conversa existente: Resultado FAIL';
	else
		raise notice 'Teste2: Jogador existente junta-se a uma conversa existente: Resultado OK';
	end if;
end;
$$;

alter procedure juntarconversa_test2() owner to postgres;

