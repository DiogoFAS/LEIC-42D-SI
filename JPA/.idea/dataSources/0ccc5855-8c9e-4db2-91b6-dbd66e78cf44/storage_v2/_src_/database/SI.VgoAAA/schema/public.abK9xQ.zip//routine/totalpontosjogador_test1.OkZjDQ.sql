create procedure totalpontosjogador_test1()
    language plpgsql
as
$$
declare 
	JogadorId int;
	totalFunc int;
	totalEstatistica int;
begin
	call criarJogador('Test', 'Test123@gmail.com', 'regiaoTest');
	
	select id into JogadorId from Jogador where email = 'Test123@gmail.com';
	
	select totalPontosJogador(JogadorId)
	into totalFunc;

	select totalPontosJogos 
	into totalEstatistica 
	from EstatisticaJogador 
	where idJogador = jogadorId;

	if totalFunc = totalEstatistica and totalFunc = 0 then
		raise notice 'Teste1: Obter total de pontos de jogador sem partidas: Resultado OK';
	else
		raise notice 'Teste1: Obter total de pontos de jogador sem partidas: Resultado FAIL';
	end if;
	
	rollback;
end;
$$;

alter procedure totalpontosjogador_test1() owner to postgres;

