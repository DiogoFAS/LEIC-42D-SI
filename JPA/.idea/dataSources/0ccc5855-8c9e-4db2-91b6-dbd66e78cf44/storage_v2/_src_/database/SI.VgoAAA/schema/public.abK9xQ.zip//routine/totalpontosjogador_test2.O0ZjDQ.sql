create procedure totalpontosjogador_test2()
    language plpgsql
as
$$
declare 
	JogadorId int;
	PartidaId int;
	totalFunc int;
	totalEstatistica int;
begin
	
	call criarJogador('Test', 'Test123@gmail.com', 'regiaoTest');
	
	select id into JogadorId from Jogador where email = 'Test123@gmail.com';
	
	insert into Partida (id, nomeJogo, dataFim)
	values (0,'Pacman', '2023-10-30 19:40:00') 
	returning id into PartidaId;
	
	insert into Normal (idPartida, nomeJogo, dificuldade, idJogador, pontuacao)
	values (PartidaId, 'Pacman', 3, JogadorId, 600);
	
	select totalPontosJogador(JogadorId)
	into totalFunc;

	select totalPontosJogos 
	into totalEstatistica 
	from EstatisticaJogador
	where idJogador = jogadorId;

	if totalFunc = totalEstatistica then
		raise notice 'Teste2: Obter total de pontos de jogador com 1 partida normal: Resultado OK';
	else
		raise notice 'Teste2: Obter total de pontos de jogador com 1 partida normal: Resultado FAIL';
	end if;
	
	rollback;
end;
$$;

alter procedure totalpontosjogador_test2() owner to postgres;

