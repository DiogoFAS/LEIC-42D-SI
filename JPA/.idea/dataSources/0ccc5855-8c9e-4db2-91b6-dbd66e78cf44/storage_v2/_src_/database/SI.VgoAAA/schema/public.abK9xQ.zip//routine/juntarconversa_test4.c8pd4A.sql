create procedure juntarconversa_test4()
    language plpgsql
as
$$
declare 
	invalidIdJogador int default 0;
	jogadorId int;
	conversaId int;
	msg text;
begin
	call criarJogador('Test5', 'Test5@gmail.com', 'regiaoTest');
	
	select id into jogadorId from Jogador where email = 'Test1@gmail.com';

	call iniciarConversa(jogadorId, 'ConversaTest', conversaId);

	begin
		call juntarConversa(invalidIdJogador, conversaId);
		exception
			when others then 
				get stacked diagnostics msg = MESSAGE_TEXT;
	
		if msg = 'Jogador com o id 0 não existe.' then 
			raise notice 'Teste1: Jogador existente junta-se a uma conversa inexistente: Resultado OK';
		else
			raise notice 'Teste1: Jogador existente junta-se a uma conversa inexistente: Resultado FAIL';
		end if;
	end;
end;
$$;

alter procedure juntarconversa_test4() owner to postgres;

