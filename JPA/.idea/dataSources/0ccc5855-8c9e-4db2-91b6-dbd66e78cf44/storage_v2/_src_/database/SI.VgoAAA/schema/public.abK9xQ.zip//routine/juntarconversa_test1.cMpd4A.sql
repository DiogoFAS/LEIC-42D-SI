create procedure juntarconversa_test1()
    language plpgsql
as
$$
declare 
	jogadorId int;
	msg text;
begin 
	call criarJogador('Test', 'Test123@gmail.com', 'regiaoTest');
	
	select id into jogadorId from Jogador where email = 'Test123@gmail.com';
	
	begin 
		call juntarConversa(jogadorId, 0);
		exception
			when others then 
				get stacked diagnostics msg = MESSAGE_TEXT;
				
		raise notice '%',msg;
			
		if msg = 'Conversa com o id 0 não existe.' then 
			raise notice 'Teste1: Jogador existente junta-se a uma conversa inexistente: Resultado OK';
		else
			raise notice 'Teste1: Jogador existente junta-se a uma conversa inexistente: Resultado FAIL';
		end if;
	end;
end;
$$;

alter procedure juntarconversa_test1() owner to postgres;

