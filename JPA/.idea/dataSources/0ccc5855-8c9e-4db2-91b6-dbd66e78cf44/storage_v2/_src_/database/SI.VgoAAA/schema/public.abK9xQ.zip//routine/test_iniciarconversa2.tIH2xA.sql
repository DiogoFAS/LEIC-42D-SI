create procedure test_iniciarconversa2()
    language plpgsql
as
$$
declare
	invalidIdJogador int default 0;
	idConversa int;
	msg text;
begin 
	set transaction isolation level read uncommitted;
	call iniciarConversa(invalidIdJogador, 'nomeDaConversa', idConversa);
	exception 
		when others then
			get stacked diagnostics msg = MESSAGE_TEXT;
				
	--correctMsg = cast(('Jogador com o id % não existe.',invalidIdJogador) as text);
	
	if msg = 'Jogador com o id 0 não existe.' then
		raise notice 'Teste1: Iniciar conversa com um jogador inexistente: Resultado OK';
	else
		raise notice 'Teste1: Iniciar conversa com um jogador inexistente: Resultado FAIL';
	end if;
rollback;
end;
$$;

alter procedure test_iniciarconversa2() owner to postgres;

