create procedure iniciarconversa_test2()
    language plpgsql
as
$$
declare
	invalidIdJogador int default 0;
	idConversa int;
	msg text;
begin
	call iniciarConversa(invalidIdJogador, 'nomeDaConversa', idConversa);
	exception 
		when others then
			get stacked diagnostics msg = MESSAGE_TEXT;
			
	if msg = 'Jogador com o id 0 não existe.' then
		raise notice 'Teste1: Iniciar conversa com um jogador inexistente: Resultado OK';
	else
		raise notice 'Teste1: Iniciar conversa com um jogador inexistente: Resultado FAIL';
	end if;
end;
$$;

alter procedure iniciarconversa_test2() owner to postgres;

